﻿:-use_module(library(lists)).

% Predicados para converter as peças de números inteiros para modo de texto.

checkPlayerColor(X,'P') :-
	X = 1,
	!.

checkPlayerColor(X,'B') :-
	X = 2,
	!.

checkPlayerColor(X,'R') :-
	X = 3,
	!.

checkPlayerColor(_,' ') :- !.

	
% Predicados para desenhar o tabuleiro em modo de texto.
	
draw([H|T]) :- 
	drawHorNumbers,
	nl,
	drawHorLine,
	drawLines([H|T]).

drawAux([],Size,_) :- 
	drawHorizontalLine(Size,Size),!.	
	
drawAux([H|T],Size,Line) :- 
	LineP is Line +1,
	drawLine(H,Size,Size,LineP),
	drawAux(T,Size,LineP),!.

drawLines([H|T]) :-
	Size is 10, % board size is always fixed at 11 (0-10)
	drawLine(H,Size,Size,0),
	drawAux(T,Size,0),!.
	
drawLine([H|T],Size,SizeS,Line) :-
	Line > 9, !,
	print(Line),
	print(' |'),
	print(' '),
	checkPlayerColor(H,Color),
	print(Color),
	S is SizeS - 1,
	drawLine(T,Size,S),!.

drawLine([H|T],Size,SizeS,Line) :-
	print(Line),
	print('  |'),
	print(' '),
	checkPlayerColor(H,Color),
	print(Color),
	S is SizeS - 1,
	drawLine(T,Size,S),!.	
	
drawLine([],_,-1) :-
	print(' |'),
	nl,!.	
	
drawLine([H|T],Size,SizeS) :-
	print('  '),
	checkPlayerColor(H,Color),
	print(Color),
	S is SizeS - 1,
	drawLine(T,Size,S),!.

drawHorNumbers :-
	Size is 10, % board size is always fixed at 11 (0-10)
	drawHorizontalNumbers(Size,Size).
	
drawHorizontalNumbers(_,-1) :- 
	nl,
	print('  '),!.
	
drawHorizontalNumbers(Size,SizeS) :- 
	SizeS =:= 0, !,
	S is SizeS - 1,	
	drawHorizontalNumbers(Size,S),
	print('   '),
	print(SizeS).	
	
drawHorizontalNumbers(Size,SizeS) :- 
	SizeS > 9, !,
	S is SizeS - 1,	
	drawHorizontalNumbers(Size,S),
	print(' '),
	print(SizeS).	
	
drawHorizontalNumbers(Size,SizeS) :- 
	S is SizeS - 1,	
	drawHorizontalNumbers(Size,S),
	print('  '),
	print(SizeS).	

drawHorLine :-
	Size is 10, % board size is always fixed at 11 (0-10)
	drawHorizontalLine(Size,Size).
	
	
drawHorizontalLine(_,-1) :-
	print('-'),
	nl,!.	
	
drawHorizontalLine(Size,SizeS) :- 
	Size =:= SizeS, !,
	S is SizeS - 1,
	print('    --'),	
	drawHorizontalLine(Size,S).	
	
drawHorizontalLine(Size,SizeS) :- 
	S is SizeS - 1,
	print('---'),	
	drawHorizontalLine(Size,S).
	
% Predicados de teste hard-coded para demonstrar os predicados de visualização em funcionamento

testeInicial :- X = [ [0 , 0 , 0 , 1 , 1 , 1 , 1 , 1 , 0 , 0 , 0], [0, 0 , 0 , 0, 0 , 1 , 0 , 0 , 0 , 0 , 0], [0, 0 , 0 , 0, 0 , 0 , 0 , 
0 , 0 , 0 , 0], [1, 0 , 0 , 0 , 0 , 2 , 0 , 0 , 0 , 0 , 1],[1 , 0 , 0 , 0 , 2 , 2 , 2 , 0 , 0 , 0 , 1], [1, 1 , 0 , 2 , 2 , 3 , 2 , 2 , 0
, 1 , 1], [1 , 0 , 0 , 0 , 2 , 2 , 2 , 0 , 0 , 0 , 1], [1, 0 , 0 , 0 , 0 , 2 , 0 , 0 , 0 , 0 , 1], [0, 0 , 0 , 0, 0 , 0 , 0 , 0 , 0 , 0 , 
0], [0, 0 , 0 , 0, 0 , 1 , 0 , 0 , 0 , 0 , 0], [0 , 0 , 0 , 1 , 1 , 1 , 1 , 1 , 0 , 0 , 0] ], draw(X,11). 
			   
testeMedio :- X = [ [0 , 0 , 0 , 0 , 1 , 1 , 0 , 0 , 1 , 0 , 0], 
			[0 , 0 , 0 , 1, 0 , 0 , 0 , 0 , 0 , 0 , 0], 
			[0, 0 , 0 , 0, 0 , 1 , 0 , 1 , 0 , 0 , 0], 
[1, 0 , 0 , 2 , 0 , 2 , 0 , 0 , 0 , 0 , 1],
[1 , 1 , 0 , 0 , 2 , 2 , 2 , 0 , 1 , 0 , 0], 
[0, 0 , 1 , 0 , 2 , 3 , 2 , 0 , 0 , 1 , 1], 
[1 , 0 , 1 , 0 , 0 , 2 , 0 , 0 , 0 , 0 , 1], 
[0, 0 , 0 , 0 , 0 , 2 , 0 , 1 , 2 , 0 , 0], 
[0, 0 ,0 , 2, 0 , 0 , 2 , 0 , 0 , 0 , 0], 
[0, 0 , 0 , 0, 0 , 1 , 0 , 0 , 0 , 0 , 0], 
[0 , 0 , 0 , 1 , 1 , 1 , 1 , 1 , 0 , 0 , 0] ], draw(X,11).


testeFinal :- X = [ [0, 0 , 0 , 0, 0 , 0 , 0 , 0 , 0 , 0 , 0], 
[0, 0 , 0 , 0, 0 , 0 , 0 , 0 , 0 , 0 , 0], 
[0, 0 , 0 , 0, 0 , 0 , 0 , 0, 0 , 0 , 0], 
[0, 0 , 0 , 0, 0 , 0 , 0 , 0 , 0 , 0 , 0],
[ 0, 0 , 0 , 0, 0 , 0 , 0 , 0 , 0 , 0 , 0], 
[0, 0 , 0 , 0, 0 , 0 , 1 , 0 , 0 , 0 ,0], 
[0, 1 , 3 , 1, 0 , 0 , 0 , 0 , 0 , 0 , 0], 
[0, 0 , 1 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0],
 [0, 0 , 0 , 0, 0 , 0 , 0 , 0 , 0 , 0 , 0], 
[0,0 , 0 , 0, 0 , 0 , 0 , 0 , 0 , 0 , 0],
 [0, 0 , 0 , 0, 0 , 0 , 0 , 0 , 0 , 0 , 0] ], draw(X,11).

			   

% Predicados para procura nas listas.

search(Piece,[Head|_]):-
	searchList(Piece,Head),!.

search(Piece,[_|Tail]) :-
	search(Piece,Tail).


searchList(Piece,List) :-
	member(Piece,List).


% Loop do jogo. Condicoes de paragem. Só para quando houver um vencedor.


play :-
		nl,
		write('********************'), nl,
		write('* Hnefatafl in Prolog *'), nl,
		write('********************'), nl,
		write('Attacking player (P) starts the game'), nl,
		initialize(Board),
		Player is 0,
		draw(Board),
		play(Board,Player,_),!.

play(Board,_,Result) :-
		game_end(Board,Result),
		!,
		announce(Board,Result).

play(Board,Player,_) :-
		ask_move(Board,Player,Xi,Yi,Xf,Yf,Piece),!,
		move([Xi,Yi,Xf,Yf,Piece],Board,[],ReturnBoard,0),
		draw(ReturnBoard),
		next_player(Player,NextPlayer),
		!, 
		play(ReturnBoard,NextPlayer,_).

move(_,[],NewBoard,NewBoard,_) :- !.

move(Move,[H|T],TempBoard,ReturnBoard,Line) :-
	move_aux(Move,H,[],List,Line,0),
	append(TempBoard,[List],NewBoard),
	Line1 is Line+1,
	move(Move,T,NewBoard,ReturnBoard,Line1).
	

move_aux(_,[],NewList,NewList,_,_) :- !.


move_aux([Xi,Yi,Xf,Yf,Piece],[_|T],TempBoard,ReturnList,Line,Col) :-
	Line = Xi,
	Col = Yi,
	append(TempBoard,[0],NewBoard),
	Col1 is Col+1,
	move_aux([Xi,Yi,Xf,Yf,Piece],T,NewBoard,ReturnList,Line,Col1),!.

move_aux([Xi,Yi,Xf,Yf,Piece],[_|T],TempBoard,ReturnList,Line,Col) :-
	Line = Xf,
	Col = Yf,
	append(TempBoard,[Piece],NewBoard),
	Col1 is Col+1,
	move_aux([Xi,Yi,Xf,Yf,Piece],T,NewBoard,ReturnList,Line,Col1),!.


move_aux(Move,[H|T],TempBoard,ReturnList,Line,Col) :-
	append(TempBoard,[H],NewBoard),
	Col1 is Col+1,
	move_aux(Move,T,NewBoard,ReturnList,Line,Col1),!.


get_piece(Board,X,Y,Piece) :-
	X >= 0,
	X < 11,
	Y >= 0,
	Y < 11,
	nth0(X,Board,Line),
	nth0(Y,Line,Piece),!.

get_piece(_,_,_,_) :-
	write('Invalid Coordinates!'),nl,fail,!.

ask_move(Board,Player,Xi,Yi,Xf,Yf,Piece) :-
	Player = 0,
	nl, write('Attackers turn. Next Move?'), nl,
	write('Xi:'),
	read(Xi), nl, 							% ask for attackers move
	write('Yi:'),
	read(Yi), nl, 							% ask for attackers move
	get_piece(Board,Xi,Yi,Piece),
	check_valid_selected_piece(Player,Piece),
	write('Xf:'),
	read(Xf), nl, 							% ask for attackers move
	write('Yf:'),
	read(Yf), nl, 							% ask for attackers move
	check_valid_move(Board,Piece,Xi,Yi,Xf,Yf),!.

ask_move(Board,Player,Xi,Yi,Xf,Yf,Piece) :-
	Player = 1,
	nl, write('Defenders turn. Next Move?'), nl,
	write('Xi:'),
	read(Xi), nl, 							% ask for defenders move
	write('Yi:'),
	read(Yi), nl, 							% ask for defenders move
	get_piece(Board,Xi,Yi,Piece),
	check_valid_selected_piece(Player,Piece),
	write('Xf:'),
	read(Xf), nl, 							% ask for defenders move
	write('Yf:'),
	read(Yf), nl, 							% ask for defenders move
	check_valid_move(Board,Piece,Xi,Yi,Xf,Yf),!.

ask_move(Board,Player,_,_,_,_,_) :-
	nl, write('Try again!'),!,
	ask_move(Board,Player,_,_,_,_,_),!.


check_valid_move(Board,_,Xi,Yi,Xf,Yf) :-
	valid_movement(Xi,Yi,Xf,Yf,MoveType),
	check_obstacles(Board,Xi,Yi,Xf,Yf,MoveType),
	check_empty_spot(Board,Xf,Yf),!.

% Checks if there is no pieces on the destination

check_empty_spot(Board,Xf,Yf) :-
	nth0(Xf,Board,Line),
	nth0(Yf,Line,Piece),
	Piece = 0,!.

check_empty_spot(_,_,_) :-
	write('There is already a piece there!'),nl,fail,!.


% given 2 numbers it returns the bigger and the smallest

min_max_number(A,B,Min,Max):-
	A > B,!,
	Min is B,
	Max is A.

min_max_number(A,B,Min,Max):-
	Min is A,
	Max is B,!.

% check_obstacles(Board,Xinitial,Yinitial,Xfinal,Yfinal,MoveType)
% MoveType - 0 = horizontal movement :: - 1 = vertical movement

check_obstacles(Board,Xi,Yi,_,Yf,0) :-
	nth0(Xi,Board,Line),
	min_max_number(Yi,Yf,Min,Max),
	Yleft is Min+1, 				% verificar obstaculos no caminho entre as duas posicoes selecionadas
	Yright is Max-1,
	check_obstacles_aux_horizontal(Line,0,Yleft,Yright,ExistObstacle),
	ExistObstacle = 0,!.

check_obstacles(Board,Xi,Yi,Xf,_,1) :-
	min_max_number(Xi,Xf,Min,Max),
	Xdown is Min+1, 				% verificar obstaculos no caminho entre as duas posicoes selecionadas
	Xup is Max-1,
	check_obstacles_aux_vertical(Board,0,Yi,Xdown,Xup,ExistObstacle),
	ExistObstacle = 0,!.

check_obstacles(_,_,_,_,_,_) :-
	write('There is a piece in the way!'),nl,fail,!.


check_obstacles_aux_vertical([],_,_,_,_,0):- !.

check_obstacles_aux_vertical(_,Line,_,_,End,0):- 
	Line > End,!.

check_obstacles_aux_vertical(Board,Line,Col,Start,_,ExistObstacle):-
	Line > Start,
	nth0(Line,Board,List),
	nth0(Col,List,Piece),
	Piece \= 0,
	ExistObstacle is 1,!.

check_obstacles_aux_vertical(Board,Line,Col,Start,End,ExistObstacle):-
	Line1 is Line+1,
	check_obstacles_aux_vertical(Board,Line1,Col,Start,End,ExistObstacle),!.	
	


% check_obstacles_aux_horizontal(Line,Col,Start,End,ExistObstacle)

check_obstacles_aux_horizontal([],_,_,_,0) :- !.

check_obstacles_aux_horizontal(_,Col,_,End,0) :- 
	Col > End,!.

check_obstacles_aux_horizontal([H|_],Col,Start,_,ExistObstacle) :-
	Col > Start,
	H \= 0,
	ExistObstacle is 1,!.

check_obstacles_aux_horizontal([_|T],Col,Start,End,ExistObstacle) :-
	Col1 is Col+1,
	check_obstacles_aux_horizontal(T,Col1,Start,End,ExistObstacle),!.


% movimento horizontal

valid_movement(Xi,Yi,Xf,Yf,MoveType) :-
	Xi = Xf,
	Yi \= Yf,!,
	MoveType is 0.

% movimento vertical

valid_movement(Xi,Yi,Xf,Yf,MoveType) :-
	Yi = Yf,
	Xi \= Xf,!,
	MoveType is 1.

valid_movement(_,_,_,_,_) :-
	write('Invalid movement!'),nl,fail,!.


check_valid_selected_piece(Player,Piece) :-
	Player = 0,
	Piece = 1,!.

check_valid_selected_piece(Player,Piece) :-
	Player = 1,
	Piece = 2,!.

check_valid_selected_piece(Player,Piece) :-
	Player = 1,
	Piece = 3,!.

check_valid_selected_piece(_,_) :-
	write('Invalid piece selected!'),fail,!.


%next_player(Player,NewPlayer) :-
next_player(0,1).
next_player(1,0).

announce(Board,Result) :-
	Result =:= 0,
	!,
	draw(Board),
	nl, write('Attackers Win!'), nl.

announce(Board,_) :-
	draw(Board),
	nl, write('Defenders Win!'), nl.

game_end(Board,Result) :-
		not_exist_King(Board),
     	!,
      	Result is 0. % Atacantes ganham

game_end(Board,Result) :-
		king_spot(Board,0,KingWin),
		KingWin =:= 1,
		!,
      	Result is 1,!. % Defensores ganham

initialize(Board) :-
	Board = [ [0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0],
			  [0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0],
			  [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
			  [1, 0, 0, 0, 0, 2, 0, 0, 0, 0, 1],
			  [1, 0, 0, 0, 2, 2, 2, 0, 0, 0, 1],
			  [1, 1, 0, 2, 2, 3, 2, 2, 0, 1, 1],
			  [1, 0, 0, 0, 2, 2, 2, 0, 0, 0, 1],
			  [1, 0, 0, 0, 0, 2, 0, 0, 0, 0, 1],
			  [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
			  [0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0],
			  [0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0] ].


% Verifica se existe algum vencedor
% not_exist_King para ver se o rei foi "comido".
% king_spot para ver o rei atingiu posicao de vitoria


% Condicoes de vitoria para atacantes e defensores.
not_exist_King(Board):-
	\+ search(3,Board).

king_spot([],_,0) :- !.

king_spot([H|_],Line,Winner) :-
	king_spot_list(H,Line,0,Winner),
	Winner =:= 1, !.

king_spot([_|T],Line,Winner) :-	
	Line1 is Line + 1,
	king_spot(T,Line1,Winner),!.

king_spot_list([],_,_,0) :- !.

king_spot_list([H|_],Line,_,Winner) :-
	Line =:= 0,
	H =:= 3,
	Winner is 1,!.

king_spot_list([H|_],Line,_,Winner) :-
	Line =:= 10,
	H =:= 3,
	Winner is 1,!.

king_spot_list([H|_],_,Col,Winner) :-
	Col =:= 0,
	H =:= 3,
	Winner is 1,!.

king_spot_list([H|_],_,Col,Winner) :-
	Col =:= 10,
	H =:= 3,
	Winner is 1,!.

king_spot_list([_|T],Line,Col,Winner) :-
	Col1 is Col+1,
	king_spot_list(T,Line,Col1,Winner),!.