:-dynamic
	cenas/1.
% Facts.

%%%%%%%%%%%%%%%%%%%%%%%%%
%           AI          %
%%%%%%%%%%%%%%%%%%%%%%%%%
% Jogadas possiveis
% play(moveFront).
% play(moveLeft).
% play(moveRight).
% play(moveBack).
% play(eatPiece).
% play(eatGuardian).
% play(moveWin).

% Prioridades nas jogadas da AI (melhorar no futuro - mais factos ).
%  Niveis AI>1,AI>2 e 3.
% moveWin
priority(moveWin,moveFront,3).
priority(moveWin,moveLeft,3).
priority(moveWin,moveRight,3).
priority(moveWin,moveBack,3).
priority(moveWin,eatPiece,3).
priority(moveWin,eatGuardian,3).
% eatGuardian
priority(eatGuardian,moveFront,3).
priority(eatGuardian,moveLeft,3).
priority(eatGuardian,moveRight,3).
priority(eatGuardian,moveBack,3).
priority(eatGuardian,eatPiece,3).
priority(eatGuardian,eatGuardian,3).
priority(eatGuardian,moveWin,2).
% eatPiece
priority(eatPiece,moveFront,2).
priority(eatPiece,moveLeft,2).
priority(eatPiece,moveRight,2).
priority(eatPiece,moveBack,2).
priority(eatPiece,eatPiece,2).
priority(eatPiece,eatGuardian,2).
priority(eatPiece,moveWin,2).
% front
priority(moveFront,moveLeft,1).
priority(moveFront,moveRight,1).
priority(moveFront,moveBack,1).
priority(moveFront,eatPiece,1).
priority(moveFront,eatGuardian,1).
priority(moveFront,moveWin,1).
% right
priority(moveRight,moveLeft,2).
priority(moveRight,moveBack,1).
priority(moveRight,eatPiece,1).
priority(moveRight,eatGuardian,1).
priority(moveRight,moveWin,1).
% left
priority(moveLeft,moveRight,1).
priority(moveLeft,moveBack,1).
priority(moveLeft,movePiece,1).
priority(moveLeft,eatGuardian,1).
priority(moveLeft,moveWin,1).
% back
priority(moveBack,eatPiece,1).
priority(moveBack,eatGuardian,1).
priority(moveBack,moveWin,1).

% C�digo next_play
% Dando uma lista de jogadas possiveis devolve qual a proxima jogada.
%
% Fim da lista. N�o encontrou nada.
loop_ListO(_,[],_,B):- B is 0,!.
% Encontrou uma jogada prioritaria. Para loop.
loop_ListO(X,[H|_],AI,B):-
	priority(X,H,AI),!,
	write(X),write(H),nl, %escreve que jogada encontrou.
	B is 1,!.
% X = H. Ir para o proximo elemento.
loop_ListO(X,[X|T],AI,B):-
	loop_ListO(X,T,AI,B),!.
% X \= H e n�o encontrou nada. Ir para o proximo.
loop_ListO(X,[_|T],AI,B):-
	loop_ListO(X,T,AI,B),!.

%Nao encontrou nada. Proxima jogada ser� a primeira da List. (aleatorio)
next_Play_Loop([],_,_,_,R):- R = 1,!.
% Se loop_ListO devolver alguma perioridade para loop e devolve a jogada a fazer.
%  Jogada igual � iteracao onde estavamos.(I)
next_Play_Loop([H|_],ListO,AI,I,R):-
	loop_ListO(H,ListO,AI,B),
	B =:= 1,
	R is I,!.
% N�o encontrou nada, segue para ao proximo elemento
next_Play_Loop([H|T],ListO,AI,I,R):-
	loop_ListO(H,ListO,AI,B),
	B =:= 0,
	NewI is I+1,
	next_Play_Loop(T,ListO,AI,NewI,R),!.

% Dando uma lista de jogadas possiveis devolve qual a proxima jogada.
next_Play(ListO,AI,R):-
	ListT = ListO,
	next_Play_Loop(ListT,ListO,AI,0,R).


% Addes the pieces in the game.

addPieces(MaxSize, MidPos, Pos, 0, Piece):-
         Pos = MidPos
	 , Piece is MaxSize+1, !.
addPieces(MaxSize, MidPos, Pos, LineNr, Piece):-
	 ((LineNr =:= MaxSize-1), (Pos=:=MidPos)), Piece is MaxSize*2+2.

addPieces(_,MidPos, Pos, 0, Piece):-
	(Pos =\= (MidPos-1) , Pos =\= (MidPos+1))
	, Piece is 1, !.

addPieces(_,MidPos, Pos, 1, Piece):-
         (Pos =:= (MidPos-1) ; Pos =:= (MidPos+1))
	 , Piece is 1, !.

addPieces(_,MidPos, Pos, 2, Piece):-
	 Pos =:= MidPos, Piece is 1.

addPieces(MaxSize,MidPos,Pos,LineNr,Piece):-
	((LineNr=:=MaxSize-1), (Pos=\=MidPos-1), (Pos=\=MidPos+1))
	, Piece is MaxSize+2.

addPieces(MaxSize,MidPos,Pos,LineNr,Piece):-
	((LineNr=:=MaxSize-2), ((Pos=:=MidPos-1); (Pos=:=MidPos+1)))
	, Piece is MaxSize+2.

addPieces(MaxSize,MidPos,Pos,LineNr,Piece):-
	((LineNr=:=MaxSize-3), (Pos=:=MidPos))
	, Piece is MaxSize+2.

addPieces(_,_,_,_, Piece):-
	Piece is 0, !.

% Inicializes the game.

generateLine(_,0,_,_,[]).
generateLine(MaxSize, BoardSize, MidPos, LineNr, List):-
	BoardVar is BoardSize-1,
	generateLine(MaxSize, BoardVar, MidPos, LineNr, List2),
	addPieces(MaxSize, MidPos, BoardVar, LineNr, P),
	append([P],List2,List),!.

generateInicialList(_,0,_,[]):-!.
generateInicialList(MaxSize,LineNr,MidPos,List):-
	NewLineNr is LineNr-1,
	generateLine(MaxSize, MaxSize, MidPos, NewLineNr, List3),
	generateInicialList(MaxSize,NewLineNr,MidPos,List2),
	append(List2,[List3],List).


% Draw the bord on the terminal.

read_element(_,0):- write('0').
read_element(Size,X):-
	CheckX is X-(Size+1),
	CheckX=0 -> write('B'), !.
read_element(Size,X):-
	CheckCalc is (Size*2)+2,
        X=:=CheckCalc -> write('P'), !.
read_element(Size,X):-
	X =<Size -> write('B'),write(X)
	; write('P'), NewX is X-(Size+1), write(NewX).

write_element(_,[]):-nl,!.
write_element(Size,[Head|Tail]):-
	write('\t'), read_element(Size,Head),
	write_element(Size,Tail).

drawPos(0):-!.
drawPos(X):-
    Xn is X-1,
    drawPos(Xn),
    write('\t'), write(X).


drawLine(_,_,[]):-!.
drawLine(MaxSize,Size,[H|T]):-
	NewSize is Size-1,
	drawLine(MaxSize,NewSize,T),
        write(Size),
	write_element(MaxSize,H).

drawBoard([H|T]):-
	length(H,MaxSize), write('Y/X'),nl,
	drawPos(MaxSize),nl,nl,
	reverse([H|T],L),
	drawLine(MaxSize, MaxSize,L),!.

% Assert Predicates.

assertBoardSize(Size,MidPos):-
	((Size > 6),(Size mod 2=:=1))
	, MidPos is ((Size+1)/2)-1, !
	; write('Invalid Board Size.'),
	MidPos is 0.

assertPlayer(Size,Player,Piece,AP):-
	(Player=0),(Piece>0),(Piece=<Size+1)
	, AP is 1, !.

assertPlayer(Size,Player,Piece,AP):-
	(Player=1),(Piece>=(Size+2)), AP is 1, !.

assertPlayer(_,_,_,0).

assertPiece(Size,Player,Board,X,Y,AP):-
	search(Board,X,Y,Piece),
	assertPlayer(Size,Player,Piece,AP).

assertLengthLimite(Xf,Yf,Size,ALL):-
	((Xf>Size);(Yf>Size))
	, ALL is 0
	; ALL is 1.

assertLength(Board,Size,PosX,PosY,X,Y,AL):-
	search(Board,PosX,PosY,P),
	assertLengthCond(Size,X,Y,P,AL).

assertLengthCond(Size,0,Y,P,AL):-
	((P=\=Size+1),(P=\=(Size*2+2))),((Y=<P),(P<Size+1);(Y=<(P-(Size+1))))
	, AL is 1,!.

assertLengthCond(Size,X,0,P,AL):-
	((P=\=Size+1),(P=\=(Size*2+2))),((X=<P),(P<Size+1);(X=<(P-(Size+1))))
	, AL is 1,!.

assertLengthCond(Size,X,Y,P,AL):-
	((P=:=Size+1);(P=:=(Size*2+2))),(((X=:=0),(Y=:=1));((X=:=1),(Y=:=0)))
	, AL is 1, !.

assertLengthCond(_,_,_,_,AL):- AL is 0.

assertJoinGuard(Size,Xi,Yi,Xf,Yf,Board,AG):-
	search(Board,Xi,Yi,Piece1),
	search(Board,Xf,Yf,Piece2),
	assertJoin(Size,Piece1,Piece2,AG).

assertJoin(Size,P1,P2,AG):-
	(((P1=:=Size+1),(P2>0),(P2<Size+1));((P2=:=Size+1),(P2>0),(P1<Size+1)))
	, AG is 0, !.

assertJoin(Size,P1,P2,AG):-
	(((P1=:=Size*2+2),(P2>Size+1));((P2=:=Size*2+2),(P1>Size+1)))
	, AG is 0, !.

assertJoin(_,_,_,AG):- AG is 1, !.


assertJump(Xi,Yi,LengthX,0,Board,ReturnAJ):-
	assertJumpLine(1,LengthX,Board,Xi,Yi,1,ReturnAJ), !.

assertJump(Xi,Yi,0,LengthY,Board,ReturnAJ):-
	assertJumpRow(1,LengthY,Board,Xi,Yi,1,ReturnAJ), !.


assertJumpLine(LengthX,LengthX,_,_,_,ReturnAJ,ReturnAJ):-!.
assertJumpLine(_,_,Board,X,Y,_,ReturnAJ):-
	NewX is X+1,
	search(Board,NewX,Y,P),
	P =\= 0
	, ReturnAJ is 0, !.

assertJumpLine(Line,LengthX,Board,X,Y,AJ,ReturnAJ):-
	NewLine is Line+1,
	NewX is X+1,
	search(Board,NewX,Y,P),
	P =:= 0,
	assertJumpLine(NewLine,LengthX,Board,NewX,Y,AJ,ReturnAJ), !.

assertJumpRow(Length,Length,_,_,_,ReturnAJ,ReturnAJ):-!.
assertJumpRow(_,_,Board,X,Y,_,ReturnAJ):-
	NewY is Y+1,
	search(Board,X,NewY,P),
	P =\= 0
	, ReturnAJ is 0, !.

assertJumpRow(Line,LengthY,Board,X,Y,AJ,ReturnAJ):-
	NewLine is Line+1,
	NewY is Y+1,
	search(Board,X,NewY,P),
	P =:= 0,
	assertJumpRow(NewLine,LengthY,Board,X,NewY,AJ,ReturnAJ), !.


adjustCoordenates(Xi,Yi,Xf,_,X,Y):-
	(Xi>Xf), X is Xf, Y is Yi, !.

adjustCoordenates(Xi,Yi,_,Yf,X,Y):-
	(Yi>Yf), Y is Yf, X is Xi, !.

adjustCoordenates(Xi,Yi,_,_,Xi,Yi).


assertStackSize(Xi,Yi,Xf,Yf,Size,Board,AS):-
	search(Board,Xi,Yi,Piece1),
	search(Board,Xf,Yf,Piece2),
	convertPiece(Piece1,Size,NewPiece1,_),
	convertPiece(Piece2,Size,NewPiece2,_),
	getLength(Xi,Xf,Yi,Yf,LengthX,LengthY),
	testGuardPiece(NewPiece1,Size,TestedPiece1,Flag),
	splitPiece(TestedPiece1,LengthX,LengthY,ReturnPiece),
	SplitedPiece is NewPiece1-ReturnPiece,
	testGuardPiece(NewPiece2,Size,TestedPiece,_),
       	assertStackSizeCond(SplitedPiece,TestedPiece,Flag,AS).

assertStackSizeCond(X,Y,0,AS):-
	X>=Y, AS is 1, !.
assertStackSizeCond(_,_,0,0):-!.
assertStackSizeCond(_,_,1,1).


% Verifica se a jogada e valida se todos os asserts derem positivo e
% devolve 1 se sim.

valid_movement(Xi,Yi,Xf,Yf,Size,Board,Player,VM):-
	assertPiece(Size,Player,Board,Xi,Yi,AP),
	assertLengthLimite(Xf,Yf,Size,ALL),
	getLength(Xi,Xf,Yi,Yf,LengthX,LengthY),
	assertLength(Board,Size,Xi,Yi,LengthX,LengthY,AL),
	adjustCoordenates(Xi,Yi,Xf,Yf,X,Y),
	assertJump(X,Y,LengthX,LengthY,Board,AJ),
	assertJoinGuard(Size,Xi,Yi,Xf,Yf,Board,AG),
	getMovementType(Xf,Yf,Size,Board,Player,Type),
	%Verifica se o jogador quer comer outra peca
	Type = 2, assertStackSize(Xi,Yi,Xf,Yf,Size,Board,AS),
	valid_movementCondition(AP,ALL,AL,AJ,AG,AS,VM), !.

valid_movement(Xi,Yi,Xf,Yf,Size,Board,Player,VM):-
	assertPiece(Size,Player,Board,Xi,Yi,AP),
	assertLengthLimite(Xf,Yf,Size,ALL),
	getLength(Xi,Xf,Yi,Yf,LengthX,LengthY),
	assertLength(Board,Size,Xi,Yi,LengthX,LengthY,AL),
	adjustCoordenates(Xi,Yi,Xf,Yf,X,Y),
	assertJump(X,Y,LengthX,LengthY,Board,AJ),
	assertJoinGuard(Size,Xi,Yi,Xf,Yf,Board,AG),
	valid_movementCondition(AP,ALL,AL,AJ,AG,1,VM), !.

valid_movementCondition(1,1,1,1,1,1,1):-!.
valid_movementCondition(_,_,_,_,_,_,0).

% Generate possible movement Predicates.

% Dadas umas coordenadas, verifica se a jogada e possivel
% e gera uma lista com as coordenadas iniciais e finais e
% o tipo de jogada (0 - mover, 1 - juntar, 2 - comer).

possiblePlay(Xi,Yi,Xf,Yf,Size,Board,Player,PlayList,ReturnList):-
	valid_movement(Xi,Yi,Xf,Yf,Size,Board,Player,Flag),
	Flag = 1,
	getMovementType(Xf,Yf,Size,Board,Player,Type),
	List = [Xi,Yi,Xf,Yf,Type],
	append(PlayList,List,ReturnList),!.

possiblePlay(_,_,_,_,_,_,_,_,[]).

% Dado umas coordenadas iniciais, gera todas as jogadas possiveis da
% pe�a no eixo dos XX's, quer no sentido positivo quer no negativo.


generatePossibleCoordsX(Height,Height,_,_,_,_,_,_,_,ReturnList,ReturnList):-!.
generatePossibleCoordsX(Height,LengthX,Xi,Yi,Xf,Yf,Size,Board,Player,PlayList,ReturnList):-
        (LengthX=<Height),
	NewXf is Xf+1,
	possiblePlay(Xi,Yi,NewXf,Yf,Size,Board,Player,[],List),
	Manhoso=[],
	List\=Manhoso,
	append(PlayList,[List],NewList),
	getLengthPosition(Xi,NewXf,Length),
	generatePossibleCoordsX(Height,Length,Xi,Yi,NewXf,Yf,Size,Board,Player,NewList,ReturnList), !.

generatePossibleCoordsX(Height,LengthX,Xi,Yi,Xf,Yf,Size,Board,Player,PlayList,ReturnList):-
	(LengthX=<Height),
	NewXf is Xf+1,
	getLengthPosition(Xi,NewXf,Length),
	generatePossibleCoordsX(Height,Length,Xi,Yi,NewXf,Yf,Size,Board,Player,PlayList,ReturnList),!.

generatePossibleCoordsXNeg(Height,Height,_,_,_,_,_,_,_,ReturnList,ReturnList):-!.
generatePossibleCoordsXNeg(Height,LengthX,Xi,Yi,Xf,Yf,Size,Board,Player,PlayList,ReturnList):-
        (LengthX=<Height),
	NewXf is Xf-1,
	possiblePlay(Xi,Yi,NewXf,Yf,Size,Board,Player,[],List),
	Manhoso=[],
	List\=Manhoso,
	append(PlayList,[List],NewList),
	getLengthPosition(NewXf,Xi,Length),
	generatePossibleCoordsXNeg(Height,Length,Xi,Yi,NewXf,Yf,Size,Board,Player,NewList,ReturnList), !.

generatePossibleCoordsXNeg(Height,LengthX,Xi,Yi,Xf,Yf,Size,Board,Player,PlayList,ReturnList):-
	(LengthX=<Height),
	NewXf is Xf-1,
	getLengthPosition(NewXf,Xi,Length),
	generatePossibleCoordsXNeg(Height,Length,Xi,Yi,NewXf,Yf,Size,Board,Player,PlayList,ReturnList),!.

% Dado umas coordenadas iniciais, gera todas as jogadas possiveis da
% pe�a no eixo dos YY's, quer no sentido positivo quer no negativo.

generatePossibleCoordsY(Height,Height,_,_,_,_,_,_,_,ReturnList,ReturnList):-!.
generatePossibleCoordsY(Height,LengthY,Xi,Yi,Xf,Yf,Size,Board,Player,PlayList,ReturnList):-
        (LengthY=<Height),
	NewYf is Yf+1,
	possiblePlay(Xi,Yi,Xf,NewYf,Size,Board,Player,[],List),
	Manhoso=[],
	List\=Manhoso,
	append(PlayList,[List],NewList),
	getLengthPosition(Yi,NewYf,Length),
	generatePossibleCoordsY(Height,Length,Xi,Yi,Xf,NewYf,Size,Board,Player,NewList,ReturnList), !.

generatePossibleCoordsY(Height,LengthY,Xi,Yi,Xf,Yf,Size,Board,Player,PlayList,ReturnList):-
	(LengthY=<Height),
	NewYf is Yf+1,
	getLengthPosition(Yi,NewYf,Length),
	generatePossibleCoordsY(Height,Length,Xi,Yi,Xf,NewYf,Size,Board,Player,PlayList,ReturnList),!.

generatePossibleCoordsYNeg(Height,Height,_,_,_,_,_,_,_,ReturnList,ReturnList):-!.
generatePossibleCoordsYNeg(Height,LengthY,Xi,Yi,Xf,Yf,Size,Board,Player,PlayList,ReturnList):-
        (LengthY=<Height),
	NewYf is Yf-1,
	possiblePlay(Xi,Yi,Xf,NewYf,Size,Board,Player,[],List),
	Manhoso=[],
	List\=Manhoso,
	append(PlayList,[List],NewList),
	getLengthPosition(NewYf,Yi,Length),
	generatePossibleCoordsYNeg(Height,Length,Xi,Yi,Xf,NewYf,Size,Board,Player,NewList,ReturnList), !.

generatePossibleCoordsYNeg(Height,LengthY,Xi,Yi,Xf,Yf,Size,Board,Player,PlayList,ReturnList):-
	(LengthY=<Height),
	NewYf is Yf-1,
	getLengthPosition(NewYf,Yi,Length),
	generatePossibleCoordsXNeg(Height,Length,Xi,Yi,Xf,NewYf,Size,Board,Player,PlayList,ReturnList),!.

% Gera todas as jogadas possiveis de um jogador ao pegar numa pe�a dele
% do tabuleiro dadas umas coordenadas.

generatePossiblePlayPiece(Xi,Yi,Size,Board,Player,ReturnList):-
	search(Board,Xi,Yi,Piece),
	convertPiece(Piece,Size,PieceHeight,_),
	generatePossibleCoordsX(PieceHeight,0,Xi,Yi,Xi,Yi,Size,Board,Player,[],ListXP),
	generatePossibleCoordsXNeg(PieceHeight,0,Xi,Yi,Xi,Yi,Size,Board,Player,[],ListXN),
	append(ListXP,ListXN,ListX),
	generatePossibleCoordsY(PieceHeight,0,Xi,Yi,Xi,Yi,Size,Board,Player,[],ListYP),
	generatePossibleCoordsYNeg(PieceHeight,0,Xi,Yi,Xi,Yi,Size,Board,Player,[],ListYN),
	append(ListYP,ListYN,ListY),
	append(ListX,ListY,ReturnList).

% Gera todas as jogadas possiveis eis de um determinado
% jogador no eixo dos XX's.

generatePossiblePlayX(0,_,_,_,_,List,List):-!.
generatePossiblePlayX(X,Y,Size,Board,Player,List,ReturnList):-
	generatePossiblePlayPiece(X,Y,Size,Board,Player,ListP),
	NewX is X -1,
	append(List,ListP,NewList),
	generatePossiblePlayX(NewX,Y,Size,Board,Player,NewList,ReturnList).

% Gera todas as jogadas possiveis no eixo dos YYs
% e chama o predicado que gera as jogadas no eixo dos XX.

generatePossiblePlay(_,0,_,_,_,ReturnList,ReturnList):-!.
generatePossiblePlay(X,Y,Size,Board,Player,List,ReturnList):-
	generatePossiblePlayX(X,Y,Size,Board,Player,[],ListX),
	append(List,ListX,NewList),
	NewY is Y-1,
	generatePossiblePlay(Size,NewY,Size,Board,Player,NewList,ReturnList).


% Dado o tamanho do tabuleiro, tabuleiro e qual jogador esta a jogar,
% devolve uma lista com todas as jogadas possiveis de todas as pe�as
% daquele jogador.

lista_jogadas(Size,Board,Player,List):-
	generatePossiblePlay(Size,Size,Size,Board,Player,[],List).

% List Search Predicates.

search(Board,X,Y,Piece):-
	searchList(Y,Board,List),
	searchList(X,List,Piece).


searchList(1, [H|_], H):- !.
searchList(Index, [_|T], ReturnList):-
	NewIndex is Index - 1,
	searchList(NewIndex, T, ReturnList).


% Replace Element in a List Predicates.

replacePiece(Index,Piece,List,NewList):-
    replacePiece(List,[],NewList,1,Index,Piece),
    !.

replacePiece([],List,List,_,_,_).
replacePiece([H|T],List,List2,NewIndex,Element,ReplaceElement) :-
    (
        ( NewIndex =:= Element
        , append(List,[ReplaceElement],NewList)
        )
    ;
        ( NewIndex =\= Element
        , append(List,[H],NewList)
        )
    ),
    Index is NewIndex + 1,
    replacePiece(T,NewList,List2,Index,Element,ReplaceElement).

replaceList(_,_,_,_,[],List,List):-!.
replaceList(ListIndex,X,Y,Element,[H|T],List,ReturnList):-
    (
         ( Y =:= ListIndex
	 , searchList(1,[H|T],L), replacePiece(X,Element,L,NewL),append(List,[NewL],List2),!
	 )
    ;
         ( Y =\= ListIndex
	 , append(List,[H],List2)
	 )
    ),
    NewIndex is ListIndex + 1,
    replaceList(NewIndex,X,Y,Element,T,List2,ReturnList).


splitPiece(Piece,Length,0,ReturnPiece):-
	ReturnPiece is Piece-Length.

splitPiece(Piece,0,Length,ReturnPiece):-
	ReturnPiece is Piece-Length.

% Mover Pe�a
replace(0,Xi,Yi,Xf,Yf,Size,_,Board,NewBoard):-
	search(Board,Xi,Yi,Piece),
	convertPiece(Piece,Size,NewPiece,CheckConvert),
        getLength(Xi,Xf,Yi,Yf,LengthX,LengthY),
	testGuardPiece(NewPiece,Size,TestedPiece,_),
	splitPiece(TestedPiece,LengthX,LengthY,ReturnPiece),
	NewCalculatedPiece is NewPiece-ReturnPiece,
	revertPiece(ReturnPiece,CheckConvert,Size,P1),
	revertPiece(NewCalculatedPiece,CheckConvert,Size,P2),
	replaceList(1,Xi,Yi,P1,Board,[],Board2),
	replaceList(1,Xf,Yf,P2,Board2,[],NewBoard), !.

% Juntar Pe�a
replace(1,Xi,Yi,Xf,Yf,Size,_,Board,NewBoard):-
	search(Board,Xi,Yi,Piece1),
	search(Board,Xf,Yf,Piece2),
	convertPiece(Piece1,Size,NewPiece1,Checker),
	convertPiece(Piece2,Size,NewPiece2,Checker),
        getLength(Xi,Xf,Yi,Yf,LengthX,LengthY),
	splitPiece(NewPiece1,LengthX,LengthY,ReturnPiece),
	NewPiece is NewPiece1-ReturnPiece + NewPiece2,
	revertPiece(NewPiece,Checker,Size,Piece),
	revertPiece(ReturnPiece,Checker,Size,Return),
	replaceList(1,Xi,Yi,Return,Board,[],Board2),
	replaceList(1,Xf,Yf,Piece,Board2,[],NewBoard).

% Comer Pe�a
replace(2,Xi,Yi,Xf,Yf,Size,Player,Board,NewBoard):-
	search(Board,Xi,Yi,Piece1),
	search(Board,Xf,Yf,Piece2),
	convertPiece(Piece1,Size,NewPiece1,Checker),
	convertPiece(Piece2,Size,NewPiece2,_),
	testGuardPiece(NewPiece1,Size,TestedPiece1,Flag),
	getLength(Xi,Xf,Yi,Yf,LengthX,LengthY),
	splitPiece(TestedPiece1,LengthX,LengthY,ReturnPiece),
	SplitedPiece is TestedPiece1-ReturnPiece,
	testGuardPiece(NewPiece2,Size,TestedPiece,_),
	((SplitedPiece >=TestedPiece);(Flag=1))
	, revertPiece(ReturnPiece,Checker,Size,Return),
	  revertPieceGuardian(SplitedPiece,Flag,Checker,Size,RevertedSplitedPiece),
	  replaceList(1,Xi,Yi,Return,Board,[],Board2),
	  replaceList(1,Xf,Yf,RevertedSplitedPiece,Board2,[],NewBoard), !
	; write('Invalid Stack Size.\n\n'), drawBoard(Board),
	  displayPlayer(Player),
	  getMovement(Size,Player,Board,NewBoard), !.

convertPiece(Piece,Size,NewPiece,Checker):-
	(Piece>Size+1)
	, NewPiece is (Piece - (Size+1)), Checker is 1, !
	; NewPiece is Piece, Checker is 0, !.


revertPiece(0,_,_,0):-!.
revertPiece(Piece,1,Size,NewPiece):-
	NewPiece is Piece+Size+1.
revertPiece(Piece,0,_,NewPiece):-
	NewPiece is Piece.

revertPieceGuardian(1,1,0,Size,Return):-
	Return is Size+1.
revertPieceGuardian(1,1,1,Size,Return):-
	Return is Size*2+2.
revertPieceGuardian(Piece,0,0,_,Return):-
	Return is Piece.
revertPieceGuardian(Piece,0,1,Size,Return):-
	Return is Piece+Size+1.

%fail safe
revertPieceGuardian(0,_,_,_,0).

testGuardPiece(P,Size,Piece,Flag):-
	P =:= Size+1, Piece is 1, Flag is 1, !.
testGuardPiece(P,_,Piece, Flag):- Piece is P, Flag is 0.

% Movement Predicates.

getLengthPosition(I,F,Length):-
	Length is abs(I - F).

getLength(Xi,Xf,Yi,Yf,LengthX,LengthY):-
	getLengthPosition(Xi,Xf,LengthX),
	getLengthPosition(Yi,Yf,LengthY).

getMovement(Size,Player,Board,NewBoard):-
	write('Xi: '), read(Xi),
	write('Yi: '), read(Yi),
	assertPiece(Size,Player,Board,Xi,Yi,AP),
	AP = 1
	, write('Xf: '), read(Xf),
	  write('Yf: '), read(Yf),
	  movePiece(Xi,Yi,Xf,Yf,Board,NewBoard,Size,Player),!
	; write('Invalid Play.\n\n'),
	  drawBoard(Board),
	  displayPlayer(Player),
	  getMovement(Size,Player,Board,NewBoard), !.


movePiece(Xi,Yi,Xf,Yf,Board,NewBoard,Size,Player):-
	assertLengthLimite(Xf,Yf,Size,ALL),
	getLength(Xi,Xf,Yi,Yf,LengthX,LengthY),
	assertLength(Board,Size,Xi,Yi,LengthX,LengthY,AL),
	adjustCoordenates(Xi,Yi,Xf,Yf,X,Y),
	assertJump(X,Y,LengthX,LengthY,Board,AJ),
	assertJoinGuard(Size,Xi,Yi,Xf,Yf,Board,AG),
	(AL = 1, ALL = 1, AJ = 1, AG = 1)
	, getMovementType(Xf,Yf,Size,Board,Player,Type),
	  executeMovement(Xi,Yi,Xf,Yf,Size,Type,Player,Board,NewBoard)
	; write('Invalid Move.\n\n'),
	  drawBoard(Board),
	  displayPlayer(Player),
	  getMovement(Size,Player,Board,NewBoard), !.

getMovementType(Xf,Yf,_,Board,_,Type):-
	 search(Board,Xf,Yf,Piece),
	 Piece = 0, Type is 0, !.

getMovementType(Xf,Yf,Size,Board,Player,Type):-
	 search(Board,Xf,Yf,Piece),
	 (((Player=0),(Piece =< Size)); ((Player=1),(Piece > (Size+1)),(Piece =< Size*2+1))), Type is 1, !.

getMovementType(Xf,Yf,Size,Board,Player,Type):-
	 search(Board,Xf,Yf,Piece),
	 (((Player=0),(Piece > (Size+1)),(Piece =< Size*2+2)); ((Player=1),(Piece =< (Size+1)))), Type is 2, !.


executeMovement(Xi,Yi,Xf,Yf,Size,Type,Player,Board,NewBoard):-
	 replace(Type,Xi,Yi,Xf,Yf,Size,Player,Board,NewBoard), !.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     victory conditions     %
%                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Verifica as flags para ver se falta algum guardiao ou se algum est� numa posicao chave.
% 00 - Erro :: 01 - ganha player 2 :: 10- ganha player 1.
check_winner_exist(0,0,Winner):-
	Winner = 3,
	write('MY_Error 001: Table without guardions or with 2 winners. Game should be terminate some plays ago.'),nl,
	!. %Tabela contem situacoes que nao podem acontecer, logo nao existe vencedor.
check_winner_exist(0,_,Winner):- Winner = 2,!.
check_winner_exist(_,0,Winner):- Winner = 1,!.
check_winner_exist(P1,P2,Winner):-
	P1 >= 1,
	P2 >= 1,
	Winner = 0. %Sem vencedor - Ambos tem guardiao

% verifica em cada linha se h� algum guardiao
exist_Guardian_Line(_,[],R):- R is 0,!.
exist_Guardian_Line(G,[G|_],R):-R is 1,!.
exist_Guardian_Line(G,[_|T],R):-
	exist_Guardian_Line(G,T,R),!.

% Verifica na matriz se h� guardiao do player X - G1-player1 G2-player2.
% Chama o predicado ..._line para verificar os elementos de uma linha.
exist_Guardian_Matrix(_,[],R):- R is 0,!.
exist_Guardian_Matrix(G1,[H|T],R):-
	exist_Guardian_Line(G1,H,R1),
	R1 =:=0,
	exist_Guardian_Matrix(G1,T,R),!.
exist_Guardian_Matrix(G1,[H|_],R):-
	exist_Guardian_Line(G1,H,R1),
	R1 =:= 1,
	R is 1,!.
% Verifica os vencedores caso existam e chama os predicado anteriores.
exist_Guardian(Size,List,Winner):-
      G1 is (Size+1),G2 is (Size*2+2),
      exist_Guardian_Matrix(G1,List,P1),
      exist_Guardian_Matrix(G2,List,P2),
      check_winner_exist(P1,P2,Winner).


% Verifica se nas duas posicoes chaves est� la o guardiao adv.
% Devolve 1,0 ou 0,1 se encontrar, devolve 1,1 se nao encontrar nada nos locais.

% Corre a linha e verifica se no meio da linha aka posicao chave esta la o guardiao adv.
guardian_Spot_Line(_,_,_,[],R):- R is 0,!.
guardian_Spot_Line(MidPos,G,MidPos,[G|_],R):- R is 1,!.
guardian_Spot_Line(LoopI,G,MidPos,[_|T],R):-
	NewLoopI is LoopI + 1,
	guardian_Spot_Line(NewLoopI,G,MidPos,T,R),!.

%Corre a matriz, chama chama o _line e verifica se existe algum guardiao na posicao certa.
guardian_Spot_Matrix(_,_,_,_,_,[],R1,R2):-
	R1=1,R2=1,!. %Empate
guardian_Spot_Matrix(_,1,G1,_,MidPos,[H|_],R1,R2):-
	guardian_Spot_Line(1,G1,MidPos,H,R1),
	R1 =:=1,
	R2 is 0,!. %Vence R1.
guardian_Spot_Matrix(Size,Size,_,G2,MidPos,[H|_],R1,R2):-
	guardian_Spot_Line(1,G2,MidPos,H,R2),
	R2=:=1,
	R1 is 0,!. %Vence R2.
guardian_Spot_Matrix(Size,LoopI,G1,G2,MidPos,[_|T],R1,R2):-
	NewLoopI is LoopI-1,
	guardian_Spot_Matrix(Size,NewLoopI,G1,G2,MidPos,T,R1,R2),!.

guardian_Spot(Size,List,Winner):-
	 G1 is (Size+1),G2 is (Size*2+2),
	 MidPos is ((Size+1)/2),
	 guardian_Spot_Matrix(Size,Size,G1,G2,MidPos,List,P1,P2),
	 check_winner_exist(P1,P2,Winner).



% Algum Vencedor? Chama ambos os predicados que verificam as conficoes finais.
% exist_ para ver se algum guardiao foi "comido".
% _spot para ver se algum guardiao atingiu uma posicao chave que d� direito a vitoria.
game_End(Size,List,Winner):-
      exist_Guardian(Size,List,ExistWinner),
      ExistWinner =\= 0,
      Winner is ExistWinner,!.
game_End(Size,List,Winner):-
      exist_Guardian(Size,List,ExistWinner),
      ExistWinner =:= 0,
      guardian_Spot(Size,List,KeyWinner),
      Winner is KeyWinner,!.

%%%%%%%%%%%%%%%%%%%%%%%%%
%                       %
% Main Game Predicates. %
%                       %
%%%%%%%%%%%%%%%%%%%%%%%%%
%display para do vencedor.
display_Winner(1):-
	nl,
	write('Player 1 Win!'),
	%write('________			 __   __    _ _       _ '),nl,
	%write('| ___ \ |                       /  |  | |  | (_)     | |'),nl,
	%write('| |_/ / | __ _ _   _  ___ _ __  `| |  | |  | |_ _ __ | |'),nl,
	%write('|  __/| |/ _` | | | |/ _ \  __|  | |  | |/\| | |  _ \| |'),nl,
	%write('| |   | | (_| | |_| |  __/ |    _| |_ \  /\  / | | | |_|'),nl,
	%write('\_|   |_|\__,_|\__, |\___|_|    \___/  \/  \/|_|_| |_(_)'),nl,
	%write('                 /  /                                   '),nl,
	%write('		|__/				        '),nl,
	nl,!.
display_Winner(2):-
	nl,
	write('Player 2 Win!'),
	%write('______ _                         _____   _    _ _       _ '),nl,
	%write('| ___ \ |                       / __  \ | |  | (_)     | |'),nl,
	%write('| |_/ / | __ _ _   _  ___ _ __  `  / /  | |  | |_ _ __ | |'),nl,
	%write('|  __/| |/ _` | | | |/ _ \  __|   / /   | |/\| | |  _ \| |'),nl,
	%write('| |   | | (_| | |_| |  __/ |    ./ /___ \  /\  / | | | |_|'),nl,
        %write('\_|   |_|\__ _|\__  |\___|_|    \_____/  \/  \/|_|_| |_(_)'),nl,
	%write('                __/ |                                     '),nl,
	%write('               |___/                                      '),nl,
	nl,!.
%Display do proximo player a jogar.
displayPlayer(0):- write('\nPlayer 1\'s turn:\n').
displayPlayer(1):- write('\nPlayer 2\'s turn:\n'),!.

% Predicado para come�ar um jogo >= 7x7.
startGame(Size):-
        assertBoardSize(Size,MidPos),
        MidPos > 0,
        generateInicialList(Size,Size,MidPos,L), nl,
	Player is 0,
	playGame(Size,Player,L,0).

% Loop do jogo. Condicoes de paragem. S� para quando houver um vencedor.
% Encontra um vencedor Player 1, faz display do Vencedor e para loot.
playGame(Size,_,Board,Winner):-
	game_End(Size,Board,Winner),
	Winner =:=1,
	drawBoard(Board),
	display_Winner(Winner),!.
% Mesma coisa mas para o Player 2.
playGame(Size,_,Board,Winner):-
	game_End(Size,Board,Winner),
	Winner =:=2,
	drawBoard(Board),
	display_Winner(Winner),!.

% N�o h� vencedor - Loop Normal
playGame(Size,Player,Board,_):-
	drawBoard(Board),
       	displayPlayer(Player),
	getMovement(Size,Player,Board,NewBoard),
	NewPlayer is 3 mod (Player+2),
	playGame(Size,NewPlayer,NewBoard,_).


